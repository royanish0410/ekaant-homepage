import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Ekaant - Agro Tourism Retreat | Bhimashankar",
  description:
    "Experience nature at its finest at Ekaant, an agro-tourism retreat near Bhimashankar Tiger Reserve, Maharashtra. Enjoy organic farming, adventure activities, and digital detox.",
  keywords: "agro tourism, bhimashankar, maharashtra, eco resort, organic farming, nature retreat",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className={inter.className}>{children}</body>
    </html>
  )
}
