"use client"

import { useState, useEffect } from "react"
import Header from "@/components/header"
import Hero from "@/components/hero"
import About from "@/components/about"
import Services from "@/components/services"
import Location from "@/components/location"
import FAQ from "@/components/faq"
import Footer from "@/components/footer"
import { contentData } from "@/data/content"

export default function HomePage() {
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simulate loading time for smooth user experience
    const timer = setTimeout(() => {
      setLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-green-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
          <p className="text-green-700 font-medium">Loading Ekaant...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      <Header data={contentData.header || {}} />
      <main>
        <Hero data={contentData.hero || {}} />
        <About data={contentData.about || {}} />
        <Services data={contentData.services || {}} />
        <Location data={contentData.location || {}} />
        <FAQ data={contentData.faqs || []} />
      </main>
      <Footer data={contentData.footer || {}} />
    </div>
  )
}
