"use client"

import { Phone, Mail, MapPin, Facebook, Instagram, Twitter } from "lucide-react"

const getSocialIcon = (platform) => {
  switch (platform.toLowerCase()) {
    case "facebook":
      return <Facebook className="w-5 h-5" />
    case "instagram":
      return <Instagram className="w-5 h-5" />
    case "twitter":
      return <Twitter className="w-5 h-5" />
    default:
      return null
  }
}

export default function Footer({ data }) {
  const currentYear = new Date().getFullYear()

  // Add default values to prevent undefined errors
  const footerData = {
    contact: {
      phone: "+91 98765 43210",
      email: "info@ekaant.com",
      address: "Bhimashankar Road, Khed, Maharashtra 410501",
    },
    social: [
      { platform: "Facebook", url: "#" },
      { platform: "Instagram", url: "#" },
      { platform: "Twitter", url: "#" },
    ],
    ...data,
  }

  return (
    <footer id="contact" className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-12">
          {/* Brand */}
          <div>
            <h3 className="text-2xl font-bold mb-4 text-green-400">EKAANT</h3>
            <p className="text-gray-300 leading-relaxed mb-6">
              Experience the perfect blend of nature, adventure, and tranquility at our agro-tourism retreat near
              Bhimashankar Tiger Reserve.
            </p>

            {/* Social Links */}
            <div className="flex space-x-4">
              {footerData.social.map((social, index) => (
                <a
                  key={index}
                  href={social.url}
                  className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-green-600 transition-colors duration-300"
                  aria-label={social.platform}
                >
                  {getSocialIcon(social.platform)}
                </a>
              ))}
            </div>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-xl font-semibold mb-6 text-green-400">Contact Us</h4>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <Phone className="w-5 h-5 text-green-400 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-gray-300">{footerData.contact.phone}</p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <Mail className="w-5 h-5 text-green-400 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-gray-300">{footerData.contact.email}</p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-green-400 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-gray-300">{footerData.contact.address}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-xl font-semibold mb-6 text-green-400">Quick Links</h4>
            <div className="space-y-3">
              {["Home", "Amenities", "Photo Gallery", "Contact Us"].map((link, index) => (
                <a
                  key={index}
                  href={`#${link.toLowerCase().replace(" ", "")}`}
                  className="block text-gray-300 hover:text-green-400 transition-colors duration-200"
                >
                  {link}
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 mt-12 pt-8 text-center">
          <p className="text-gray-400">
            © {currentYear} Ekaant Agro Tourism. All rights reserved. | Designed with ❤️ for nature lovers
          </p>
        </div>
      </div>
    </footer>
  )
}
