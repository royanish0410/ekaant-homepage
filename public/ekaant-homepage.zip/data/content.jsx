export const contentData = {
  header: {
    logo: "EKAANT",
    navigation: [
      { label: "Home", href: "#home" },
      { label: "About", href: "#about" },
      { label: "Amenities", href: "#amenities" },
      { label: "Location", href: "#location" },
      { label: "Contact Us", href: "#contact" },
    ],
  },
  hero: {
    title: "Welcome to Ekaant",
    subtitle: "Your Agro-Tourism Retreat in Bhimashankar",
    backgroundImage: "/hero-image.jpg",
  },
  about: {
    title: "Experience Nature's Bliss",
    content:
      "Ekaant is an agro-tourism retreat nestled near the Bhimashankar Tiger Reserve in Maharashtra. We offer a unique blend of nature, adventure, and tranquility, allowing you to escape the hustle and bustle of city life and reconnect with the natural world.",
    features: [
      "Organic Farming Experience",
      "Adventure Activities",
      "Digital Detox",
      "Comfortable Accommodations",
      "Delicious Local Cuisine",
    ],
    image: "/about-image.jpg",
  },
  services: {
    title: "Our Amenities",
    items: [
      { title: "Farm Fresh Dining", image: "/service1.jpg" },
      { title: "Nature Trails", image: "/service2.jpg" },
      { title: "Bonfire Nights", image: "/service3.jpg" },
      { title: "Organic Farming", image: "/service4.jpg" },
      { title: "Bird Watching", image: "/service5.jpg" },
      { title: "Adventure Activities", image: "/service6.jpg" },
    ],
  },
  location: {
    title: "Getting Here",
    methods: [
      {
        type: "By Road",
        details: [
          "From Mumbai: Approximately 4 hours drive via NH48.",
          "From Pune: Approximately 3 hours drive via SH110.",
        ],
      },
      {
        type: "By Train",
        details: ["Nearest railway station: Pune (PNQ).", "From Pune, hire a taxi or take a bus to Bhimashankar."],
      },
      {
        type: "By Air",
        details: [
          "Nearest airport: Pune International Airport (PNQ).",
          "From the airport, hire a taxi to Bhimashankar.",
        ],
      },
    ],
  },
  faqs: [
    {
      question: "What is agro-tourism?",
      answer:
        "Agro-tourism is a form of tourism that involves visiting working farms or agricultural settings for recreational or educational purposes.",
    },
    {
      question: "What activities are available at Ekaant?",
      answer:
        "We offer a variety of activities, including organic farming experiences, nature trails, bird watching, adventure activities, and bonfire nights.",
    },
    {
      question: "What type of accommodation do you offer?",
      answer:
        "We provide comfortable and eco-friendly accommodations that blend seamlessly with the natural surroundings.",
    },
    {
      question: "Is Ekaant suitable for families?",
      answer: "Yes, Ekaant is a family-friendly destination with activities for all ages.",
    },
    {
      question: "How can I book my stay at Ekaant?",
      answer: "You can book your stay by visiting our website or contacting us directly.",
    },
  ],
  footer: {
    contact: {
      phone: "+91 98765 43210",
      email: "info@ekaant.com",
      address: "Bhimashankar Road, Khed, Maharashtra 410501",
    },
    social: [
      { platform: "Facebook", url: "#" },
      { platform: "Instagram", url: "#" },
      { platform: "Twitter", url: "#" },
    ],
  },
}
